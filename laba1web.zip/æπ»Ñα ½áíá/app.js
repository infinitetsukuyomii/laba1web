"use strict";

// Класи для структури резюме
class PersonalInfo {
  constructor(name, age, contacts) {
    this.name = name;
    this.age = Number(age);
    this.contacts = contacts;
  }

  get info() {
    return `Ім'я: ${this.name}, Вік: ${this.age}, Контакти: ${this.contacts}`;
  }
}

class Education {
  constructor(description) {
    this.description = description;
  }
}

class Experience {
  constructor(description) {
    this.description = description;
  }
}

class Skills {
  constructor(skillList) {
    this.skills = skillList;
  }

  get formattedSkills() {
    return this.skills.map((s, i) => `${i + 1}. ${s}`).join("<br>");
  }
}

// Основний клас Резюме
class Resume {
  constructor(personalInfo, education, experience, skills) {
    this.personalInfo = personalInfo;
    this.education = education;
    this.experience = experience;
    this.skills = skills;
  }

  display() {
    return `
      <div class="resume-section"><strong>Особиста інформація:</strong><br>${this.personalInfo.info}</div>
      <div class="resume-section"><strong>Освіта:</strong><br>${this.education.description}</div>
      <div class="resume-section"><strong>Досвід роботи:</strong><br>${this.experience.description}</div>
      <div class="resume-section"><strong>Навички:</strong><br>${this.skills.formattedSkills}</div>
    `;
  }
}

// Замикання для валідації
function validator(fieldName) {
  return function(value) {
    if (!value || value.trim() === "") {
      alert(`Поле "${fieldName}" не може бути порожнім`);
      throw new Error(`Помилка в полі ${fieldName}`);
    }
    return value.trim();
  };
}

// Каррінг для обробки рядків
const processSkills = str => str.split(",").map(s => s.trim()).filter(Boolean);

// Збір даних і створення об'єкта резюме
function createResume() {
  try {
    const validate = validator("Введене значення");

    const name = validate(document.getElementById("name").value);
    const age = validate(document.getElementById("age").value);
    const contacts = validate(document.getElementById("contacts").value);
    const education = validate(document.getElementById("education").value);
    const experience = validate(document.getElementById("experience").value);
    const skills = processSkills(validate(document.getElementById("skills").value));

    const personal = new PersonalInfo(name, age, contacts);
    const edu = new Education(education);
    const exp = new Experience(experience);
    const skl = new Skills(skills);

    const resume = new Resume(personal, edu, exp, skl);

    document.getElementById("resumeDisplay").innerHTML = resume.display();

    localStorage.setItem("resumeData", JSON.stringify({ name, age, contacts, education, experience, skills }));
  } catch (e) {
    console.error("Помилка при створенні резюме:", e.message);
  }
}

// Редагування (заповнення полів з localStorage)
function editResume() {
  const saved = JSON.parse(localStorage.getItem("resumeData"));
  if (!saved) {
    alert("Немає збереженого резюме");
    return;
  }

  document.getElementById("name").value = saved.name;
  document.getElementById("age").value = saved.age;
  document.getElementById("contacts").value = saved.contacts;
  document.getElementById("education").value = saved.education;
  document.getElementById("experience").value = saved.experience;
  document.getElementById("skills").value = saved.skills.join(", ");
  createResume(); // Одразу відображаємо
}

// Очистка збережених даних
function clearStorage() {
  localStorage.removeItem("resumeData");
  alert("Збережені дані очищено");
  document.getElementById("resumeDisplay").innerHTML = "";
}
